import AzAnimationFourth from "./src/AzAnimationFourth"

AzAnimationFourth.install = function (Vue,opts) {
  Vue.component(AzAnimationFourth.name,AzAnimationFourth)
}

export default AzAnimationFourth

