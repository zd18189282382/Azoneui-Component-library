import AzTableSecond from "./src/AzTableSecond"

AzTableSecond.install = function (Vue,opts) {
  Vue.component(AzTableSecond.name,AzTableSecond)
}

export default AzTableSecond

