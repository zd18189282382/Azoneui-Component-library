import AzTheSlider from "./src/AzTheSlider"

AzTheSlider.install = function (Vue,opts) {
  Vue.component(AzTheSlider.name,AzTheSlider)
}

export default AzTheSlider

