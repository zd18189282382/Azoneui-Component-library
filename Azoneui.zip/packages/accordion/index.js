import AzAccordion from "./src/AzAccordion"

AzAccordion.install = function (Vue,opts) {
  Vue.component(AzAccordion.name,AzAccordion)
}

export default AzAccordion
