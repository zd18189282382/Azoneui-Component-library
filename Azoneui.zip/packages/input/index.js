import AzInput from "./src/AzInput"

AzInput.install = function (Vue,opts) {
  Vue.component(AzInput.name,AzInput)
}

export default AzInput
