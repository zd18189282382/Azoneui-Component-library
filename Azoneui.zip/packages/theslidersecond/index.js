import AzTheSliderSecond from "./src/AzTheSliderSecond"

AzTheSliderSecond.install = function (Vue,opts) {
  Vue.component(AzTheSliderSecond.name,AzTheSliderSecond)
}

export default AzTheSliderSecond

