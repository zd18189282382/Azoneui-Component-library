import AzYzm from "./src/AzYzm"
AzYzm.install = function (Vue,opts) {
  Vue.component(AzYzm.name,AzYzm)

}

export default AzYzm
