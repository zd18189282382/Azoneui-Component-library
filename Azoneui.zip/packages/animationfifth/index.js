import AzAnimationFifth from "./src/AzAnimationFifth"

AzAnimationFifth.install = function (Vue,opts) {
  Vue.component(AzAnimationFifth.name,AzAnimationFifth)
}

export default AzAnimationFifth

