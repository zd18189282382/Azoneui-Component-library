import AzAnimationSecond from "./src/AzAnimationSecond"

AzAnimationSecond.install = function (Vue,opts) {
  Vue.component(AzAnimationSecond.name,AzAnimationSecond)
}

export default AzAnimationSecond

