import AzColorPicker from "./src/AzColorPicker"

AzColorPicker.install = function (Vue,opts) {
  Vue.component(AzColorPicker.name,AzColorPicker)
}

export default AzColorPicker
