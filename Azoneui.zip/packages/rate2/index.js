
import AzRateTwo from './src/AzRateTwo'

AzRateTwo.install = function (Vue,opts) {
  Vue.component(AzRateTwo.name,AzRateTwo)
}

export default AzRateTwo
