<template>
    
</template>

<script>
    export default {
        name: "MySearch"
    }
</script>

<style scoped>

</style>
