
import AzRate from './src/AzRate'

AzRate.install = function (Vue,opts) {
  Vue.component(AzRate.name,AzRate)
}

export default AzRate
