<template>
  <div>
    <!--heart-->
    <div id="loading">
      <div id="loader" class="heart"></div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "AzAnimationThird"
  }
</script>

<style scoped>
  @import "../../libs/theme/animationthird.css";
</style>

