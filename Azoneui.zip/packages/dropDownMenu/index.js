import AzDropDownMenu from "./src/AzDropDownMenu"

AzDropDownMenu.install = function (Vue,opts) {
  Vue.component(AzDropDownMenu.name,AzDropDownMenu)
}

export default AzDropDownMenu
