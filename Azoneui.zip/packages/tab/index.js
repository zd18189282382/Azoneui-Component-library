import AzTab from "./src/AzTab"

AzTab.install = function (Vue,opts) {
  Vue.component(AzTab.name,AzTab)
}

export default AzTab

