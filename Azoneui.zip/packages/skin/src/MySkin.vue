<template>
    
</template>

<script>
    export default {
        name: "MySkin"
    }
</script>

<style scoped>

</style>
