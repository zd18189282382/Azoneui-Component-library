import AzAnimationEighteen from "./src/AzAnimationEighteen"

AzAnimationEighteen.install = function (Vue,opts) {
  Vue.component(AzAnimationEighteen.name,AzAnimationEighteen)
}

export default AzAnimationEighteen

