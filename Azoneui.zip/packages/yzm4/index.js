import AzYzmFoure from "./src/AzYzmFoure"
AzYzmFoure.install = function (Vue,opts) {
  Vue.component(AzYzmFoure.name,AzYzmFoure)

}

export default AzYzmFoure
