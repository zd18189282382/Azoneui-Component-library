import AzAnimationSevteen from "./src/AzAnimationSevteen"

AzAnimationSevteen.install = function (Vue,opts) {
  Vue.component(AzAnimationSevteen.name,AzAnimationSevteen)
}

export default AzAnimationSevteen

