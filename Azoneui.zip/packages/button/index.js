import AzButton from "./src/AzButton"

AzButton.install = function (Vue,opts) {
  Vue.component(AzButton.name,AzButton)
}

export default AzButton
