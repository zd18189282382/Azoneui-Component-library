import AzForm from "./src/AzForm"

AzForm.install = function (Vue,opts) {
  Vue.component(AzForm.name,AzForm)
}

export default AzForm
